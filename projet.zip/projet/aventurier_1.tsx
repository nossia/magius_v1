<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="aventurier_1" tilewidth="16" tileheight="16" tilecount="368" columns="23">
 <image source="aventurier_1.png" trans="ffffff" width="383" height="261"/>
</tileset>
