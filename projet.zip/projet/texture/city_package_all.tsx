<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="city_package_all" tilewidth="16" tileheight="16" tilecount="4256" columns="16">
 <image source="city_package_all.png" width="256" height="4256"/>
</tileset>
