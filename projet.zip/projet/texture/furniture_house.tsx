<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="furniture_house" tilewidth="16" tileheight="16" tilecount="3300" columns="44">
 <grid orientation="orthogonal" width="30" height="17"/>
 <image source="furniture_house.png" width="718" height="1214"/>
</tileset>
