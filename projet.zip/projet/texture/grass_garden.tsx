<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="grass_garden" tilewidth="16" tileheight="16" tilecount="450" columns="25">
 <image source="grass_garden.png" width="401" height="302"/>
</tileset>
