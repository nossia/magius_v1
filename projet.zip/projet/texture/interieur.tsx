<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="interieur" tilewidth="16" tileheight="16" tilecount="1764" columns="42">
 <image source="interieur.png" width="675" height="672"/>
</tileset>
