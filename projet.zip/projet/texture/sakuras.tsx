<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="sakuras" tilewidth="16" tileheight="16" tilecount="3078" columns="54">
 <image source="sakuras.png" width="864" height="912"/>
</tileset>
