<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="tree_house" tilewidth="16" tileheight="16" tilecount="525" columns="21">
 <image source="tree_house.png" width="350" height="400"/>
</tileset>
