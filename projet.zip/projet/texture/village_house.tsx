<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="village_house" tilewidth="16" tileheight="16" tilecount="837" columns="31">
 <image source="village_house.png" width="496" height="432"/>
</tileset>
