<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="village_villas" tilewidth="16" tileheight="16" tilecount="600" columns="25">
 <image source="village_villas.png" width="403" height="397"/>
</tileset>
