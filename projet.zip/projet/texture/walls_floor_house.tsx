<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="walls_floor_house" tilewidth="16" tileheight="16" tilecount="1680" columns="30">
 <image source="walls_floor_house.png" width="490" height="898"/>
</tileset>
